#Requires -Version 5.1
<#
.SYNOPSIS
    Restore Intune configurations from backup

.DESCRIPTION
    Restores Intune device configurations, policies, and profiles from a backup folder.
    This script will create new policies or update existing ones based on displayName.

.PARAMETER ConfigFile
    Path to param.json configuration file (default: script directory)

.PARAMETER BackupPath
    Path to specific backup folder (if empty, will prompt to select)

.PARAMETER Verbose
    Show detailed progress information

.EXAMPLE
    .\restore-intune-backup.ps1

.EXAMPLE
    .\restore-intune-backup.ps1 -BackupPath "C:\map\intune\backup\20251120_170041" -Verbose
#>

param(
    [string]$ConfigFile = "",
    [string]$BackupPath = "",
    [switch]$Verbose = $false
)

$ErrorActionPreference = "Stop"

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  INTUNE RESTORE                                       " -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# Determine config file path
if ([string]::IsNullOrWhiteSpace($ConfigFile)) {
    # Try param-user.json first, then fallback to param.json
    $userConfigFile = Join-Path $PSScriptRoot "param-user.json"
    $defaultConfigFile = Join-Path $PSScriptRoot "param.json"
    
    if (Test-Path $userConfigFile) {
        $ConfigFile = $userConfigFile
    }
    elseif (Test-Path $defaultConfigFile) {
        $ConfigFile = $defaultConfigFile
    }
    else {
        $ConfigFile = $userConfigFile  # Default to param-user.json for error message
    }
}

# Load configuration
if (-not (Test-Path $ConfigFile)) {
    Write-Host "[X] Configuration file not found: $ConfigFile" -ForegroundColor Red
    Write-Host "    Create a param-user.json file with TenantId, BackupPath, and UserAccount" -ForegroundColor Yellow
    Write-Host "    Or create a param.json file with TenantId, ClientId, ClientSecret, and BackupPath" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

try {
    $config = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
    $TenantId = $config.TenantId

    if ([string]::IsNullOrWhiteSpace($BackupPath)) {
        $BackupPath = $config.BackupPath
    }
    
    # Check if using service principal or user authentication
    $UseServicePrincipal = $false
    if ($config.Restore -and $config.Restore.ClientId -and $config.Restore.ClientSecret) {
        $UseServicePrincipal = $true
        $ClientId = $config.Restore.ClientId
        $ClientSecret = $config.Restore.ClientSecret
    }
    elseif ($config.UserAccount) {
        $UserAccount = $config.UserAccount
    }
}
catch {
    Write-Host "[X] Error reading configuration: $_" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Determine if we need to select a backup folder
$needsSelection = $false

if ([string]::IsNullOrWhiteSpace($BackupPath)) {
    $needsSelection = $true
    $basePath = $config.BackupPath
}
elseif (Test-Path $BackupPath) {
    # Check if this is a base folder with backup subfolders or an actual backup folder
    $subfolders = Get-ChildItem -Path $BackupPath -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^\d{8}_\d{6}$' }

    if ($subfolders.Count -gt 0) {
        # This is a base folder, need to select
        $needsSelection = $true
        $basePath = $BackupPath
    }
    else {
        # This is an actual backup folder, use it
        $needsSelection = $false
    }
}
else {
    Write-Host "[X] Backup path not found: $BackupPath" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

if ($needsSelection) {
    Write-Host "[>] Searching for available backups..." -ForegroundColor Yellow

    if (-not (Test-Path $basePath)) {
        Write-Host "[X] Backup folder not found: $basePath" -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit 1
    }

    $backupFolders = Get-ChildItem -Path $basePath -Directory |
        Where-Object { $_.Name -match '^\d{8}_\d{6}$' } |
        Sort-Object Name -Descending

    if ($backupFolders.Count -eq 0) {
        Write-Host "[X] No backups found in: $basePath" -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit 1
    }

    Write-Host ""
    Write-Host "Available backups:" -ForegroundColor Cyan
    Write-Host ""

    for ($i = 0; $i -lt $backupFolders.Count; $i++) {
        $folder = $backupFolders[$i]
        $date = [datetime]::ParseExact($folder.Name, "yyyyMMdd_HHmmss", $null)
        $displayDate = $date.ToString("yyyy-MM-dd HH:mm:ss")
        $fileCount = (Get-ChildItem -Path $folder.FullName -Recurse -Filter "*.json" -ErrorAction SilentlyContinue).Count

        if ($i -eq 0) {
            Write-Host "  [$($i + 1)] $displayDate - $fileCount files [MOST RECENT]" -ForegroundColor Green
        } else {
            Write-Host "  [$($i + 1)] $displayDate - $fileCount files" -ForegroundColor White
        }
    }

    Write-Host ""
    $selection = Read-Host "Select backup [1-$($backupFolders.Count)] or press Enter for most recent"

    if ([string]::IsNullOrWhiteSpace($selection)) {
        $BackupPath = $backupFolders[0].FullName
    } else {
        $index = [int]$selection - 1
        if ($index -lt 0 -or $index -ge $backupFolders.Count) {
            Write-Host "[X] Invalid selection" -ForegroundColor Red
            Read-Host "Press Enter to exit"
            exit 1
        }
        $BackupPath = $backupFolders[$index].FullName
    }

    Write-Host ""
}

Write-Host "[OK] Using backup: $BackupPath" -ForegroundColor Green
Write-Host ""

# Ask confirmation
Write-Host "========================================================" -ForegroundColor Yellow
Write-Host "  WARNING" -ForegroundColor Yellow
Write-Host "========================================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "You are about to restore Intune configurations!" -ForegroundColor Yellow
Write-Host "This will create new policies or update existing ones." -ForegroundColor Yellow
Write-Host ""
$confirmation = Read-Host "Are you sure you want to continue? (type YES)"

if ($confirmation -ne "YES") {
    Write-Host "[!] Restore cancelled" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 0
}

Write-Host ""

# Load modules
Write-Host "[>] Loading modules..." -ForegroundColor Yellow
$modules = @('Microsoft.Graph.Authentication', 'Microsoft.Graph.DeviceManagement')
foreach ($mod in $modules) {
    if (-not (Get-Module -ListAvailable $mod)) {
        Install-Module $mod -Scope CurrentUser -Force -AllowClobber
    }
    Import-Module $mod -Force
}
Write-Host "[OK] Modules loaded" -ForegroundColor Green
Write-Host ""

# Connect
Write-Host "[>] Connecting to Microsoft Graph..." -ForegroundColor Yellow
if ($UseServicePrincipal) {
    $secureSecret = ConvertTo-SecureString $ClientSecret -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($ClientId, $secureSecret)
    Connect-MgGraph -TenantId $TenantId -ClientSecretCredential $credential -NoWelcome
}
else {
    # User authentication - interactive login with Microsoft Graph
    Write-Host "Logging in with Microsoft Graph..." -ForegroundColor Yellow

    # Define required scopes for Intune restore operations
    $scopes = @(
        "DeviceManagementConfiguration.ReadWrite.All",
        "DeviceManagementApps.ReadWrite.All",
        "DeviceManagementServiceConfig.ReadWrite.All",
        "DeviceManagementManagedDevices.ReadWrite.All"
    )

    try {
        # Connect with interactive browser login
        Connect-MgGraph -TenantId $TenantId -Scopes $scopes -NoWelcome -ErrorAction Stop
    }
    catch {
        Write-Host "[X] Failed to connect: $_" -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit 1
    }
}

$ctx = Get-MgContext
Write-Host "[OK] Connected: $($ctx.TenantId)" -ForegroundColor Green
Write-Host ""

# Helper function to read JSON
function Get-BackupItem {
    param($Path)
    try {
        $json = Get-Content -Path $Path -Raw -Encoding UTF8
        return ($json | ConvertFrom-Json)
    }
    catch {
        Write-Host "    [!] Error reading: $($Path | Split-Path -Leaf)" -ForegroundColor Red
        if ($Verbose) {
            Write-Host "        Details: $($_.Exception.Message)" -ForegroundColor Yellow
        }
        return $null
    }
}

# Helper function to clean JSON for restore
function Clean-RestoreData {
    param($Data, $Uri)

    # Remove read-only properties
    $Data.PSObject.Properties.Remove('id')
    $Data.PSObject.Properties.Remove('createdDateTime')
    $Data.PSObject.Properties.Remove('lastModifiedDateTime')
    $Data.PSObject.Properties.Remove('@odata.context')
    $Data.PSObject.Properties.Remove('version')
    $Data.PSObject.Properties.Remove('supportsScopeTags')
    $Data.PSObject.Properties.Remove('roleScopeTagIds')

    # Remove null properties that cause issues
    $nullProps = @('deviceManagementApplicabilityRuleOsEdition',
                   'deviceManagementApplicabilityRuleDeviceMode',
                   'deviceManagementApplicabilityRuleOsVersion',
                   'enrollmentStatusScreenSettings',
                   'updateWeeks')
    foreach ($prop in $nullProps) {
        if ($Data.PSObject.Properties.Name -contains $prop -and $null -eq $Data.$prop) {
            $Data.PSObject.Properties.Remove($prop)
        }
    }

    # Specific cleanup for Autopilot profiles
    if ($Uri -like "*windowsAutopilotDeploymentProfiles*") {
        $Data.PSObject.Properties.Remove('enableWhiteGlove')
        $Data.PSObject.Properties.Remove('hardwareHashExtractionEnabled')
        $Data.PSObject.Properties.Remove('outOfBoxExperienceSetting')
        $Data.PSObject.Properties.Remove('managementServiceAppId')
        $Data.PSObject.Properties.Remove('language')
    }

    # Specific cleanup for Device Configurations
    if ($Uri -like "*deviceConfigurations*") {
        $Data.PSObject.Properties.Remove('featureUpdatesPauseExpiryDateTime')
        $Data.PSObject.Properties.Remove('qualityUpdatesPauseExpiryDateTime')
        $Data.PSObject.Properties.Remove('qualityUpdatesRollbackStartDateTime')
        $Data.PSObject.Properties.Remove('featureUpdatesRollbackStartDateTime')

        if ($Data.'@odata.type' -eq '#microsoft.graph.windowsUpdateForBusinessConfiguration') {
            $Data.PSObject.Properties.Remove('featureUpdatesPauseStartDate')
            $Data.PSObject.Properties.Remove('qualityUpdatesPauseStartDate')
            $Data.PSObject.Properties.Remove('featureUpdatesWillBeRolledBack')
            $Data.PSObject.Properties.Remove('qualityUpdatesWillBeRolledBack')
            $Data.PSObject.Properties.Remove('featureUpdatesRollbackWindowInDays')
        }
    }

    return $Data
}

# Helper function to restore item
function Restore-IntuneItem {
    param($Uri, $Body, $Name, $NameProperty = "displayName")

    try {
        # Clean the data
        $Body = Clean-RestoreData -Data $Body -Uri $Uri

        # Check if item already exists
        $existingItems = Invoke-MgGraphRequest -Uri $Uri -Method GET
        $existingItem = $existingItems.value | Where-Object { $_.$NameProperty -eq $Name }

        $jsonBody = $Body | ConvertTo-Json -Depth 100 -Compress

        if ($existingItem) {
            # UPDATE
            $updateUri = "$Uri/$($existingItem.id)"
            Write-Host "    [~] Updating: $Name" -ForegroundColor Cyan

            try {
                $result = Invoke-MgGraphRequest -Uri $updateUri -Method PATCH -Body $jsonBody -ContentType "application/json"
                Write-Host "        [OK] Updated successfully" -ForegroundColor Green
                return "updated"
            }
            catch {
                Write-Host "        [X] Update failed: $($_.Exception.Message)" -ForegroundColor Red
                return $false
            }
        }
        else {
            # CREATE
            Write-Host "    [+] Creating: $Name" -ForegroundColor Green

            try {
                $result = Invoke-MgGraphRequest -Uri $Uri -Method POST -Body $jsonBody -ContentType "application/json"
                Write-Host "        [OK] Created successfully" -ForegroundColor Green
                return "created"
            }
            catch {
                Write-Host "        [X] Create failed: $($_.Exception.Message)" -ForegroundColor Red
                return $false
            }
        }
    }
    catch {
        Write-Host "    [X] Error processing: $Name" -ForegroundColor Red
        Write-Host "        Details: $($_.Exception.Message)" -ForegroundColor Yellow
        return $false
    }
}

$totalRestored = 0
$totalCreated = 0
$totalUpdated = 0

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  RESTORE STARTED" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# Device Configurations
Write-Host "[>] Device Configurations..." -ForegroundColor Cyan
$folder = Join-Path $BackupPath "Configurations"
$count = 0
$created = 0
$updated = 0

if (Test-Path $folder) {
    $files = Get-ChildItem -Path $folder -Filter "*.json"
    Write-Host "    Found $($files.Count) configuration file(s)" -ForegroundColor Gray

    foreach ($file in $files) {
        $data = Get-BackupItem -Path $file.FullName
        if ($data -and $data.displayName) {
            $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations"
            $result = Restore-IntuneItem -Uri $uri -Body $data -Name $data.displayName

            if ($result -eq "created") { $created++; $count++ }
            elseif ($result -eq "updated") { $updated++; $count++ }
        }
    }
}
else {
    Write-Host "    [!] Folder not found: Configurations" -ForegroundColor Yellow
}

Write-Host "[OK] $count configurations ($created new, $updated updated)" -ForegroundColor Green
$totalRestored += $count
$totalCreated += $created
$totalUpdated += $updated
Write-Host ""

# Administrative Templates
Write-Host "[>] Administrative Templates..." -ForegroundColor Cyan
$folder = Join-Path $BackupPath "AdminTemplates"
$count = 0
$created = 0
$updated = 0

if (Test-Path $folder) {
    $files = Get-ChildItem -Path $folder -Filter "*.json"
    Write-Host "    Found $($files.Count) template file(s)" -ForegroundColor Gray

    foreach ($file in $files) {
        $data = Get-BackupItem -Path $file.FullName
        if ($data -and $data.displayName) {
            # Remove definitionValues for templates
            $data.PSObject.Properties.Remove('definitionValues')

            $uri = "https://graph.microsoft.com/beta/deviceManagement/groupPolicyConfigurations"
            $result = Restore-IntuneItem -Uri $uri -Body $data -Name $data.displayName

            if ($result -eq "created") { $created++; $count++ }
            elseif ($result -eq "updated") { $updated++; $count++ }
        }
    }
}
else {
    Write-Host "    [!] Folder not found: AdminTemplates" -ForegroundColor Yellow
}

Write-Host "[OK] $count templates ($created new, $updated updated)" -ForegroundColor Green
$totalRestored += $count
$totalCreated += $created
$totalUpdated += $updated
Write-Host ""

# Autopilot Profiles
Write-Host "[>] Autopilot Profiles..." -ForegroundColor Cyan
$folder = Join-Path $BackupPath "Autopilot"
$count = 0
$created = 0
$updated = 0

if (Test-Path $folder) {
    $files = Get-ChildItem -Path $folder -Filter "*.json"
    Write-Host "    Found $($files.Count) profile file(s)" -ForegroundColor Gray

    foreach ($file in $files) {
        $data = Get-BackupItem -Path $file.FullName
        if ($data -and $data.displayName) {
            $uri = "https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeploymentProfiles"
            $result = Restore-IntuneItem -Uri $uri -Body $data -Name $data.displayName

            if ($result -eq "created") { $created++; $count++ }
            elseif ($result -eq "updated") { $updated++; $count++ }
        }
    }
}
else {
    Write-Host "    [!] Folder not found: Autopilot" -ForegroundColor Yellow
}

Write-Host "[OK] $count profiles ($created new, $updated updated)" -ForegroundColor Green
$totalRestored += $count
$totalCreated += $created
$totalUpdated += $updated
Write-Host ""

# Completion
Write-Host "========================================================" -ForegroundColor Green
Write-Host "  RESTORE COMPLETED!" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Total items: $totalRestored" -ForegroundColor Yellow
Write-Host "  - Created: $totalCreated" -ForegroundColor Green
Write-Host "  - Updated: $totalUpdated" -ForegroundColor Cyan
Write-Host "Backup location: $BackupPath" -ForegroundColor Gray
Write-Host ""
Write-Host "IMPORTANT:" -ForegroundColor Yellow
Write-Host "- Check the Intune portal to verify everything is correct" -ForegroundColor Yellow
Write-Host "- Policy assignments are NOT restored (must be done manually)" -ForegroundColor Yellow
Write-Host ""

Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null

Write-Host "Press Enter to exit..." -ForegroundColor Cyan
Read-Host
