#Requires -Version 5.1
param(
    [string]$ConfigFile = ""
)

$ErrorActionPreference = "Stop"

# Determine config file path (default to script directory)
if ([string]::IsNullOrWhiteSpace($ConfigFile)) {
    # Try param-user.json first, then fallback to param.json
    $userConfigFile = Join-Path $PSScriptRoot "param-user.json"
    $defaultConfigFile = Join-Path $PSScriptRoot "param.json"
    
    if (Test-Path $userConfigFile) {
        $ConfigFile = $userConfigFile
    }
    elseif (Test-Path $defaultConfigFile) {
        $ConfigFile = $defaultConfigFile
    }
    else {
        $ConfigFile = $userConfigFile  # Default to param-user.json for error message
    }
}

# Load configuration from param.json or param-user.json
if (-not (Test-Path $ConfigFile)) {
    Write-Host "[X] Configuration file not found: $ConfigFile" -ForegroundColor Red
    Write-Host "    Create a param-user.json file with TenantId, BackupPath, and UserAccount" -ForegroundColor Yellow
    Write-Host "    Or create a param.json file with TenantId, ClientId, ClientSecret, and BackupPath" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

try {
    $config = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
    $TenantId = $config.TenantId
    $BackupPath = $config.BackupPath
    
    # Check if using service principal or user authentication
    $UseServicePrincipal = $false
    if ($config.Backup -and $config.Backup.ClientId -and $config.Backup.ClientSecret) {
        $UseServicePrincipal = $true
        $ClientId = $config.Backup.ClientId
        $ClientSecret = $config.Backup.ClientSecret
    }
    elseif ($config.UserAccount) {
        $UserAccount = $config.UserAccount
    }
}
catch {
    Write-Host "[X] Error reading configuration file: $_" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "=== INTUNE FULL BACKUP ===" -ForegroundColor Cyan
Write-Host ""

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$folder = Join-Path $BackupPath $ts
New-Item -Path $folder -ItemType Directory -Force | Out-Null
Write-Host "Folder: $folder" -ForegroundColor Green
Write-Host ""

Write-Host "Loading modules..." -ForegroundColor Yellow
if (-not (Get-Module -ListAvailable Microsoft.Graph.Authentication)) {
    Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force
}
if (-not (Get-Module -ListAvailable Microsoft.Graph.DeviceManagement)) {
    Install-Module Microsoft.Graph.DeviceManagement -Scope CurrentUser -Force
}
Import-Module Microsoft.Graph.Authentication -Force
Import-Module Microsoft.Graph.DeviceManagement -Force

Write-Host "Connecting..." -ForegroundColor Yellow
if ($UseServicePrincipal) {
    $secureSecret = ConvertTo-SecureString $ClientSecret -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($ClientId, $secureSecret)
    Connect-MgGraph -TenantId $TenantId -ClientSecretCredential $credential -NoWelcome
}
else {
    # User authentication - interactive login with Microsoft Graph
    Write-Host "Logging in with Microsoft Graph..." -ForegroundColor Yellow

    # Define required scopes for Intune backup operations
    $scopes = @(
        "DeviceManagementConfiguration.Read.All",
        "DeviceManagementApps.Read.All",
        "DeviceManagementServiceConfig.Read.All",
        "DeviceManagementManagedDevices.Read.All"
    )

    try {
        # Connect with interactive browser login
        Connect-MgGraph -TenantId $TenantId -Scopes $scopes -NoWelcome -ErrorAction Stop
    }
    catch {
        Write-Host "[X] Failed to connect: $_" -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit 1
    }
}
Write-Host "Connected!" -ForegroundColor Green
Write-Host ""

function Save-Item {
    param($Cat, $Name, $Data, $Path)
    $catPath = Join-Path $Path $Cat
    if (-not (Test-Path $catPath)) {
        New-Item -Path $catPath -ItemType Directory -Force | Out-Null
    }
    $safe = $Name -replace '[\/:*?"<>|]', '_'
    $file = Join-Path $catPath "$safe.json"
    $Data | ConvertTo-Json -Depth 100 | Out-File $file -Encoding UTF8
}

$total = 0

Write-Host "1. Compliance Policies..." -ForegroundColor Cyan
$uri = "https://graph.microsoft.com/beta/deviceManagement/deviceCompliancePolicies"
$data = Invoke-MgGraphRequest -Uri $uri -Method GET
$count = 0
if ($data.value) {
    foreach ($item in $data.value) {
        Save-Item -Cat "Compliance" -Name $item.displayName -Data $item -Path $folder
        $count++
    }
}
Write-Host "   -> $count" -ForegroundColor Green
$total += $count

Write-Host "2. Device Configurations..." -ForegroundColor Cyan
$uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations"
$data = Invoke-MgGraphRequest -Uri $uri -Method GET
$count = 0
if ($data.value) {
    foreach ($item in $data.value) {
        Save-Item -Cat "Configurations" -Name $item.displayName -Data $item -Path $folder
        $count++
    }
}
Write-Host "   -> $count" -ForegroundColor Green
$total += $count

Write-Host "3. Configuration Policies..." -ForegroundColor Cyan
$uri = "https://graph.microsoft.com/beta/deviceManagement/configurationPolicies"
$data = Invoke-MgGraphRequest -Uri $uri -Method GET
$count = 0
if ($data.value) {
    foreach ($item in $data.value) {
        Save-Item -Cat "ConfigPolicies" -Name $item.name -Data $item -Path $folder
        $count++
    }
}
Write-Host "   -> $count" -ForegroundColor Green
$total += $count

Write-Host "4. Administrative Templates..." -ForegroundColor Cyan
$uri = "https://graph.microsoft.com/beta/deviceManagement/groupPolicyConfigurations"
$data = Invoke-MgGraphRequest -Uri $uri -Method GET
$count = 0
if ($data.value) {
    foreach ($item in $data.value) {
        Save-Item -Cat "AdminTemplates" -Name $item.displayName -Data $item -Path $folder
        $count++
    }
}
Write-Host "   -> $count" -ForegroundColor Green
$total += $count

Write-Host "5. App Protection..." -ForegroundColor Cyan
$count = 0
$uri = "https://graph.microsoft.com/beta/deviceAppManagement/iosManagedAppProtections"
$data = Invoke-MgGraphRequest -Uri $uri -Method GET
if ($data.value) {
    foreach ($item in $data.value) {
        Save-Item -Cat "AppProtection" -Name $item.displayName -Data $item -Path $folder
        $count++
    }
}
$uri = "https://graph.microsoft.com/beta/deviceAppManagement/androidManagedAppProtections"
$data = Invoke-MgGraphRequest -Uri $uri -Method GET
if ($data.value) {
    foreach ($item in $data.value) {
        Save-Item -Cat "AppProtection" -Name $item.displayName -Data $item -Path $folder
        $count++
    }
}
Write-Host "   -> $count" -ForegroundColor Green
$total += $count

Write-Host "6. Endpoint Security..." -ForegroundColor Cyan
$uri = "https://graph.microsoft.com/beta/deviceManagement/intents"
$data = Invoke-MgGraphRequest -Uri $uri -Method GET
$count = 0
if ($data.value) {
    foreach ($item in $data.value) {
        Save-Item -Cat "EndpointSecurity" -Name $item.displayName -Data $item -Path $folder
        $count++
    }
}
Write-Host "   -> $count" -ForegroundColor Green
$total += $count

Write-Host "7. Autopilot Profiles..." -ForegroundColor Cyan
$count = 0
try {
    $uri = "https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeploymentProfiles"
    $data = Invoke-MgGraphRequest -Uri $uri -Method GET
    if ($data.value) {
        foreach ($item in $data.value) {
            Save-Item -Cat "Autopilot" -Name $item.displayName -Data $item -Path $folder
            $count++
        }
    }
    Write-Host "   -> $count" -ForegroundColor Green
    $total += $count
}
catch {
    Write-Host "   -> Permission required: DeviceManagementServiceConfig.Read.All" -ForegroundColor Yellow
}

Write-Host "8. Mobile Apps..." -ForegroundColor Cyan
$count = 0
try {
    $uri = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps"
    $data = Invoke-MgGraphRequest -Uri $uri -Method GET
    if ($data.value) {
        foreach ($item in $data.value) {
            Save-Item -Cat "Apps" -Name $item.displayName -Data $item -Path $folder
            $count++
        }
    }
    Write-Host "   -> $count" -ForegroundColor Green
    $total += $count
}
catch {
    Write-Host "   -> Permission required: DeviceManagementApps.Read.All" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "=== DONE ===" -ForegroundColor Green
Write-Host "Total: $total items" -ForegroundColor Yellow
Write-Host "Location: $folder" -ForegroundColor Yellow
Write-Host ""

Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null

Read-Host "Press Enter"
